
run with python3 tool.py <path_to_repo>/program.json <path_to_repo>/patterns.json
